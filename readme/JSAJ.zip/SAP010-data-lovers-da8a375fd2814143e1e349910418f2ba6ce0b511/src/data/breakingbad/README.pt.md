# Breaking Bad

Breaking Bad é uma série de televisão americana criada e
produzida por Vince Gilligan. Ambientado e produzido em
Albuquerque, Novo México, segue a história de Walter White,
um professor de química que é diagnosticado com câncer de
pulmão inoperável. Walter se volta para uma vida de crime
produzindo e distribuindo metanfetamina ao lado de um
ex-aluno, Jesse Pinkman, a fim de arrecadar dinheiro
suficiente para o futuro de sua família após sua morte
inevitável.

## Constatações

Fazendo uma investigação (pesquisa) sobre as
informações que nossas usuárias podem precisar,
descobrimos que os dados de maior interesse são:

- Informações sobre os personagens como nome, apelido,
ocupação e nome da atriz ou ator que o interpreta.

- Além dessas informações, Breaking Bad coexiste
com Better Call Saul; para nossos usuários é
importante poder ver a lista de personagens que
aparecem em cada uma das séries.

## Detalhes dos data

Com este conjunto de dados você pode obter os seguintes dados de um caractere:

- nome
- imagem
- ocupação
- estado de vida
- sobrenome
- categoria
- estação em que aparece
