# Rick and Morty

Rick y Morty es una serie de televisión estadounidense de animación para
adultos. La serie tiene gran acogida a nivel mundial, de todo este fandom hay
un grupo que desea poder interactuar y ver la información de los personajes y
de la serie en general.

## Hallazgos

Hicimos una rápida investigación sobre la información que podrían necesitar
nuestros usuarios y encontramos que los datos de mayor interés para ellos son:

Información relevante sobre los personajes, como nombre, género, especie, lugar
de origen, imagen y episodios donde aparece.

Adicionalmente a esta información, para nuestros usuarios es importante poder
ver la lista de personajes que aparecen en la serie, la cantidad de
episodios, los diferentes lugares de origen, para tener mayor información de la
serie.

## Detalles de la data

* Con este set de datos puedes obtener los siguientes datos de un personaje:

  - nombre
  - imagen
  - estado de vida
  - especie
  - género
  - lugar de origen (planeta tierra)
  - lugar donde vive.
  - episodios donde aparece.

* Con este set de datos también puedes obtener lo siguiente:

  - Cantidad de personajes.
  - Cantidad de lugares de origen.
  - Lista de episodios de la serie.
  - Lista de personajes que pertenecen a una cierta locación.
  - Todos los personajes de la serie.
