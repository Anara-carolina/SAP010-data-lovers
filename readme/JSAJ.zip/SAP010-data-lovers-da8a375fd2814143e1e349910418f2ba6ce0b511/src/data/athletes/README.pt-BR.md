# Jogos Olímpicos do Rio de Janeiro

Jogos Olímpicos do Rio de Janeiro, foi um evento multiesportivo internacional,
realizado na cidade do Rio de Janeiro, Brasil. A escolha do Rio marcou a
primeira vez em que o evento foi realizado em um país sul-americano. Este evento
foi bem recebido em todo o mundo, e dentre todas essas pessoas há um grupo que
quer ser capaz de interagir e ver informações sobre os atletas, esportes
olímpicos e países que participaram do evento.

## Achados

Para entender melhor quais informações nossos usuários podem precisar,
fizemos uma investigação rápida (research) e essas são algumas das conclusões.

- Informações relevantes sobre atletas olímpicos, como nome, altura, peso,
país que representa e especialidade esportiva
- Nos Jogos Olímpicos há muitos países participantes, para nossos usuários é
importante saber quais são
- Além dessas informações, é importante que nossos usuários possam ver o
número de atletas participantes por país
- Nos jogos olímpicos existem esportes e esses têm suas disciplinas, para nossos
usuários, é importante saber quantos e quais são
- Nos jogos olímpicos sempre há equipes ou atletas que vencem diferentes
disciplinas, para os nossos usuários é importante saber quem eles são e quantas
medalhas eles ganharam
- Além disso, nossos usuários gostariam de saber o número de mulheres
atletas que participaram e ganharam medalhas.
