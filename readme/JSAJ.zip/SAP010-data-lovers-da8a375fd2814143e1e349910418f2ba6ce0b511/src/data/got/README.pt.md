# Game of Thrones

"Game of Thrones" é uma série dramática de televisão e
fantasia épica criada por David Benioff e D.B. Weiss,
Baseado na série de romances "As Crônicas de Gelo e Fogo"
do autor George R. R. Martin. A série acompanha as lutas e
conflitos entre várias casas nobres no continente fictício
de Westeros, enquanto competem pelo Trono de Ferro e pelo
controle dos Sete Reinos.

## Constatações

Fazendo pesquisas sobre
informações que nosso
usuários, descobrimos que os dados com maior
interesse são:

- Informações sobre os personagens como nome,
título, imagem e família

Além dessas informações, é importante que nossos usuários possam ver a
lista de personagens que aparecem em
a série e o número de membros em cada família para
tem mais informações sobre a série.

## Detalhes dos data

- nome
- sobrenome
- qualificação
- família
- imagem
- ano de nascimento
- ano da morte
