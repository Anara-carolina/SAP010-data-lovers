# FAQ (preguntas frecuentes)

- [Diferencia entre array y objetos](https://youtu.be/mJJloQY7A8Y)
- [¿Cómo agrego una nueva propiedad a un objeto?](https://youtu.be/mJJloQY7A8Y?t=236)
- [¿Cómo puedo recorrer un objeto?](https://youtube.com/01RHn23Bn_0)
- [map, filter, sort y reduce también son métodos para objetos](https://youtu.be/bUl1R2lQvKo)
- [Diferencia entre expression y statements](https://youtu.be/wlukoWco2zk)
- [Diferencia entre createElement e innerHTML](https://www.javascripttutorial.net/javascript-dom/javascript-innerhtml-vs-createelement/)
- [¿Qué es el Scope?](https://youtu.be/s-7C09ymzK8)
- ¿Qué es git y por qué debo usarlo?
- GitHub Colaborativo
- ¿Qué es un Merge y existen alternativas? (Rebase)
- ¿Existe una "buena forma" de usar git?

[Para estas preguntas sobre Git recomendamos ver este playlist](https://www.youtube.com/watch?v=F1EoBbvhaqU&list=PLiAEe0-R7u8k9o3PbT3_QdyoBW_RX8rnV)
